from kafka import KafkaProducer
from kafka.errors import kafka_errors
from time import sleep
from json import dumps
import pandas as pd
import sys
from kafka import KafkaAdminClient
from kafka.admin import NewTopic

# Configure Kafka admin client
bootstrap_servers = 'localhost:9092'
topic = 'train'

# Create Kafka admin client
admin_client = KafkaAdminClient(bootstrap_servers=bootstrap_servers)

# Delete the topic
admin_client.delete_topics(topics=[topic])

# Close the admin client
admin_client.close()

topic = 'train'
producer = KafkaProducer(bootstrap_servers=bootstrap_servers,
                         value_serializer=lambda x: dumps(x).encode('utf-8')
                        ,key_serializer= lambda x: dumps(x).encode('utf-8'))

def send(file_path='./code/send.csv'):
    df = pd.read_csv(file_path)    
    # Send each row to Kafka topic
    df.drop("Unnamed: 0",inplace=True,axis=1)
    counter = 0  # Counter variable to track the number of rows processed
    #print(df.shape)
    for index, row in df.iloc[:2000,:].iterrows():
        #print(index)
        #if counter >= 25:
            #print('done producer')
            #break # Exit the loop after processing 100 rows
    
        # Serialize the key
        key = {'id': index}
    
        # Serialize the value
        value = row.to_dict()
    
        # Send the serialized key-value pair to Kafka topic
        producer.send(topic, key=key, value=value)
        #print('send')
    
        counter += 1  # Increment the counter
        sleep(1)
        producer.flush()
    
        # Sleep for a moment to simulate real-time streaming
        # Close the Kafka producer
    producer.close()
send()