import subprocess
from time import sleep
import subprocess
# Run script.py
script_process = subprocess.Popen(['python3', 'Code/script.py'])
sleep(50)
# Run consumer.py
consumer_process = subprocess.Popen(['python3', 'Code/consumer.py'])
sleep(40)

# Run producer.py
producer_process = subprocess.Popen(['python3', 'Code/producer.py'])

# Wait for producer.py to complete
producer_process.wait()

sleep(20)
# Terminate script.py and consumer.py
consumer_process.terminate()
script_process.terminate()


# Wait for script.py and consumer.py to terminate
script_process.wait()
consumer_process.wait()
sleep(2)
subprocess.run('stop-dfs.sh', shell=True, check=True)
print("All processes completed.")
